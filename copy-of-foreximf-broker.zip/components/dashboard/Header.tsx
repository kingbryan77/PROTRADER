import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BellIcon, UserCircleIcon, MagnifyingGlassIcon, Bars3Icon } from '@heroicons/react/24/outline';
import NotificationDropdown from './NotificationDropdown';
import ProfileDropdown from './ProfileDropdown';
import { useAuth } from '../../context/AuthContext';
import { useTransactions } from '../../context/TransactionContext';
import TickerTapeWidget from './TickerTapeWidget';

interface HeaderProps {
    onToggleSidebar?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onToggleSidebar }) => {
  const { user } = useAuth();
  const { balance, notifications, accountMode, toggleAccountMode } = useTransactions();
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  const formatCurrency = (amount: number): string => {
    return `Rp ${amount.toLocaleString('id-ID')}`;
  };

  const profileImgSrc = user?.profilePictureUrl || `https://ui-avatars.com/api/?name=${user?.username || 'User'}&background=random`;

  return (
    <>
    {/* =======================
        DESKTOP HEADER (Hidden on Mobile)
       ======================= */}
    <header className="hidden lg:flex fixed top-0 left-64 right-0 bg-headerBlue h-16 z-40 items-center justify-between px-4 shadow-md transition-all duration-300">
      <div></div> {/* Spacer */}
      <div className="flex items-center space-x-4">
        {/* Desktop Controls (Existing Logic) */}
        <button onClick={toggleAccountMode} className="flex items-center bg-black/20 hover:bg-black/30 rounded px-3 py-1.5 transition-all">
          <span className="mr-2 text-white font-sans tabular-nums text-sm font-semibold">{formatCurrency(balance)}</span>
          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${accountMode === 'real' ? 'bg-success text-white' : 'bg-warning text-black'}`}>
            {accountMode === 'real' ? 'Real' : 'Demo'}
          </span>
        </button>

        <button className="p-2 text-white/80 hover:text-white">
            <MagnifyingGlassIcon className="h-5 w-5" />
        </button>

        <div className="relative">
          <button onClick={() => setIsNotificationsOpen(!isNotificationsOpen)} className="p-2 text-white/80 hover:text-white relative">
            <BellIcon className="h-6 w-6" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1 right-1 bg-danger text-white text-[8px] font-bold rounded-full h-3 w-3 flex items-center justify-center border border-headerBlue"></span>
            )}
          </button>
          {isNotificationsOpen && <NotificationDropdown notifications={notifications} onClose={() => setIsNotificationsOpen(false)} />}
        </div>

        <div className="relative">
          <button onClick={() => setIsProfileOpen(!isProfileOpen)} className="flex items-center focus:outline-none ml-1">
             <img src={profileImgSrc} alt="Profile" className="h-8 w-8 rounded-full object-cover border-2 border-white/50" />
          </button>
          {isProfileOpen && <ProfileDropdown onClose={() => setIsProfileOpen(false)} />}
        </div>
      </div>
    </header>

    {/* =======================
        MOBILE HEADER (Visible only on Mobile)
       ======================= */}
    <div className="lg:hidden fixed top-0 left-0 right-0 z-40 flex flex-col">
        {/* ROW 1: Logo & Slogan (Dark Background) */}
        <div className="bg-[#151922] py-4 flex flex-col items-center justify-center border-b border-gray-800 shadow-sm relative z-50">
             <h1 className="text-3xl font-extrabold text-white tracking-wide">FOREX<span className="text-headerBlue">imf</span></h1>
             <p className="text-[10px] text-gray-400 tracking-[0.2em] font-medium mt-1">TRADING LIKE A PRO</p>
        </div>

        {/* ROW 2: Cyan Bar (Navigation & Controls) */}
        <div className="bg-[#00C0EF] h-16 flex items-center justify-between px-4 shadow-md relative z-40">
            {/* Left: Hamburger Only */}
            <div className="flex items-center">
                <button onClick={onToggleSidebar} className="text-white focus:outline-none p-1">
                    <Bars3Icon className="h-8 w-8" />
                </button>
            </div>

            {/* Center: Balance Toggle */}
            <div 
                onClick={toggleAccountMode}
                className="flex items-center bg-[#151922]/80 rounded-md overflow-hidden cursor-pointer border border-white/20 shadow-inner"
            >
                <div className="px-3 py-1.5 text-white font-sans font-bold text-sm tracking-wide">
                    {formatCurrency(balance)}
                </div>
                <div className={`px-2 py-1.5 text-[10px] font-bold uppercase ${accountMode === 'real' ? 'bg-success text-white' : 'bg-warning text-black'}`}>
                    {accountMode === 'real' ? 'Real' : 'Demo'}
                </div>
            </div>

            {/* Right: Notification & Profile */}
            <div className="flex items-center space-x-3">
                 {/* Notification */}
                <div className="relative">
                    <button onClick={() => setIsNotificationsOpen(!isNotificationsOpen)} className="text-white relative p-1">
                        <BellIcon className="h-7 w-7" />
                        <span className="absolute top-1 right-0 bg-danger h-2.5 w-2.5 rounded-full border border-[#00C0EF]"></span>
                    </button>
                    {isNotificationsOpen && (
                         <div className="absolute right-[-50px] top-10">
                             <NotificationDropdown notifications={notifications} onClose={() => setIsNotificationsOpen(false)} />
                         </div>
                    )}
                </div>

                {/* Profile Button - Removed dots */}
                <div className="relative">
                    <button onClick={() => setIsProfileOpen(!isProfileOpen)} className="flex items-center">
                        <div className="h-9 w-9 rounded-full overflow-hidden border-2 border-white">
                            <img src={profileImgSrc} alt="Profile" className="h-full w-full object-cover" />
                        </div>
                    </button>
                    {isProfileOpen && (
                        <div className="absolute right-0 top-10">
                            <ProfileDropdown onClose={() => setIsProfileOpen(false)} />
                        </div>
                    )}
                </div>
            </div>
        </div>
    </div>

    {/* =======================
        TICKER (Running Text) -> Replaced with TradingView Ticker Tape
       ======================= */}
    <div className="fixed top-[138px] lg:top-16 left-0 lg:left-64 right-0 h-12 bg-[#1A1F29] border-b border-t border-gray-800 z-30">
        <TickerTapeWidget />
    </div>
    </>
  );
};

export default Header;