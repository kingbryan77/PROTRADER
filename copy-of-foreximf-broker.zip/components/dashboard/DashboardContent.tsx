import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import ForexCrossRatesWidget from './ForexCrossRatesWidget';
import { HomeIcon } from '@heroicons/react/24/solid';

const DashboardContent: React.FC = () => {
  const { user } = useAuth();
  const [referralLink] = useState(`https://FOREX IMF/?reff=${user?.username || 'member'}`);
  const [copyBtnText, setCopyBtnText] = useState('Copy Reff URL');

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink);
    setCopyBtnText('Copied!');
    setTimeout(() => setCopyBtnText('Copy Reff URL'), 2000);
  };

  return (
    <div className="container mx-auto px-0 lg:px-6 space-y-6">
      
      {/* 1. Dashboard Title Card (Matches Screenshot) */}
      <div className="bg-[#2C3139] rounded-lg p-6 shadow-lg mb-6 mx-2 sm:mx-0">
          <h1 className="text-3xl font-medium text-white tracking-wide">Dashboard</h1>
          <p className="text-gray-400 text-lg mb-4 font-light">Control panel</p>
          
          <div className="bg-[#1D2127] py-2 px-3 rounded flex items-center text-xs text-white w-fit">
              <HomeIcon className="w-3 h-3 mr-2" />
              <span className="mr-2">Home</span>
              <span className="mr-2 text-gray-500">{'>'}</span>
              <span className="text-gray-400">Dashboard</span>
          </div>
      </div>

      {/* 2. Referral Section (Matches Screenshot) */}
      <div className="mx-2 sm:mx-0 mb-6">
         <div className="flex flex-col sm:flex-row shadow-lg rounded-md overflow-hidden">
             <div className="flex-grow bg-[#2C3139] border border-gray-600 p-3 flex items-center">
                 <span className="text-gray-400 truncate w-full text-sm font-sans">{referralLink}</span>
             </div>
             <button 
                onClick={handleCopy}
                className="bg-[#00C0EF] hover:bg-cyan-500 text-white font-medium px-6 py-3 text-sm transition-colors whitespace-nowrap"
             >
                {copyBtnText}
             </button>
         </div>
      </div>

      {/* 3. Forex Cross Rates Section */}
      <div className="mx-2 sm:mx-0 bg-[#2C3139] rounded-lg border border-gray-700 shadow-2xl overflow-hidden h-[600px] flex flex-col">
        {/* Simple gray header for table similar to screenshot style */}
        <div className="px-4 py-3 border-b border-gray-600 bg-gray-700">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center">
                <img src="https://flagcdn.com/w20/eu.png" className="w-4 h-3 mr-2 inline-block" alt="EU" /> 
                Market Overview (Forex)
            </h2>
        </div>
        
        <div className="flex-grow w-full bg-gray-800 relative">
            <ForexCrossRatesWidget />
        </div>
      </div>

    </div>
  );
};

export default DashboardContent;