import React from 'react';

const InvestmentPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4 md:p-6 lg:p-8">
      <h2 className="text-3xl font-bold text-white mb-6">Investment</h2>
      <div className="bg-darkblue2 p-6 rounded-lg shadow-md">
        <p className="text-gray-400">
          This page would allow users to manage their investments, view portfolio performance, and explore investment opportunities.
        </p>
        <p className="text-gray-500 mt-4">
          Example: Show investment products, user's current portfolio, ROI.
        </p>
      </div>
    </div>
  );
};

export default InvestmentPage;
