import React, { useState, useEffect } from 'react';
import { useTransactions } from '../../context/TransactionContext';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine
} from 'recharts';
import { HomeIcon, CameraIcon, Cog6ToothIcon, ArrowsPointingOutIcon } from '@heroicons/react/24/outline';

// --- Helper Components ---

// Custom Candlestick Shape
const Candlestick = (props: any) => {
  const { x, y, width, height, low, high, open, close } = props;
  const isBullish = close > open;
  const color = isBullish ? '#0ECB81' : '#F6465D';
  
  const pixelHeight = height;
  const priceRange = high - low;
  if (priceRange === 0 || isNaN(pixelHeight)) return null;

  const priceToPixel = (price: number) => {
    const diffFromHigh = high - price;
    return y + (diffFromHigh / priceRange) * pixelHeight;
  };

  const yOpen = priceToPixel(open);
  const yClose = priceToPixel(close);
  const bodyTop = Math.min(yOpen, yClose);
  const bodyHeight = Math.max(Math.abs(yOpen - yClose), 1);

  return (
    <g>
      <line x1={x + width / 2} y1={y} x2={x + width / 2} y2={y + height} stroke={color} strokeWidth={1} />
      <rect x={x} y={bodyTop} width={width} height={bodyHeight} fill={color} stroke={color} />
    </g>
  );
};

// Date Formatter (e.g., Monday, 24-Nov-2025 11:09:44)
const formatDate = (date: Date) => {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const dayName = days[date.getDay()];
  const day = date.getDate().toString().padStart(2, '0');
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const seconds = date.getSeconds().toString().padStart(2, '0');

  return `${dayName}, ${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
};

// --- Main Page ---
const TradePage: React.FC = () => {
  const { balance } = useTransactions();
  
  // State
  const [chartData, setChartData] = useState<any[]>([]);
  const [currentPrice, setCurrentPrice] = useState(0.03248);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Timer State
  const [countdown, setCountdown] = useState(3573); // 59m 33s in seconds

  // Data Generation
  useEffect(() => {
    // Initial Chart Data
    const initialData = [];
    let price = 0.03248;
    for (let i = 0; i < 60; i++) {
      const open = price;
      const close = price + (Math.random() - 0.5) * 0.0001;
      const high = Math.max(open, close) + Math.random() * 0.00005;
      const low = Math.min(open, close) - Math.random() * 0.00005;
      initialData.push({ time: i, open, high, low, close });
      price = close;
    }
    setChartData(initialData);

    // Live Chart Updates & Time
    const interval = setInterval(() => {
      setCurrentTime(new Date());
      
      // Update Timer
      setCountdown(prev => (prev > 0 ? prev - 1 : 0));

      // Update Chart
      setChartData(prev => {
        const last = prev[prev.length - 1];
        const change = (Math.random() - 0.5) * 0.00002;
        const close = last.close + change;
        const next = {
             ...last,
             high: Math.max(last.high, close),
             low: Math.min(last.low, close),
             close
        };
        setCurrentPrice(close);
        return [...prev.slice(0, -1), next];
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  
  // Calculate formatted times
  const formatCountdown = (seconds: number) => {
      const h = Math.floor(seconds / 3600);
      const m = Math.floor((seconds % 3600) / 60);
      const s = seconds % 60;
      return `00d ${h.toString().padStart(2, '0')}h ${m.toString().padStart(2, '0')}m ${s.toString().padStart(2, '0')}s`;
  };

  const stakeDate = currentTime;
  const endDate = new Date(stakeDate.getTime() + 60 * 60 * 1000); // + 1 Hour

  // Calculate Y Domain
  const minPrice = Math.min(...chartData.map(d => d.low));
  const maxPrice = Math.max(...chartData.map(d => d.high));
  const padding = (maxPrice - minPrice) * 0.1;

  return (
    <div className="container mx-auto px-4 lg:px-6">
      
      {/* 1. Header Breadcrumb */}
      <div className="mb-4">
        <h2 className="text-3xl font-bold text-white mb-2">Trade</h2>
        <div className="bg-[#1E2329] border-x border-b border-borderGray p-2 px-4 rounded-b-lg flex items-center text-xs text-gray-400">
             <HomeIcon className="w-3 h-3 mr-1" /> 
             <span className="mx-1">Home</span> 
             <span className="mx-1">{'>'}</span> 
             <span className="text-white">Trade</span>
         </div>
      </div>

      {/* 2. Main Chart Card */}
      <div className="bg-darkblue2 border border-borderGray rounded-lg overflow-hidden mb-6">
          {/* Chart Header Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-center p-3 border-b border-borderGray bg-[#161A1E]">
               <div className="flex items-center space-x-4 mb-2 sm:mb-0">
                   <div className="flex items-center text-white font-bold text-sm">
                       <span className="mr-2">ETH/BTC</span>
                   </div>
                   <div className="hidden md:flex space-x-1">
                       <button className="p-1 hover:bg-gray-700 rounded text-gray-400"><Cog6ToothIcon className="w-4 h-4" /></button>
                       <span className="text-gray-600">|</span>
                       {['1m', '30m', '1h'].map(t => (
                           <button key={t} className={`px-2 text-xs rounded ${t === '1h' ? 'text-white bg-gray-700' : 'text-gray-400 hover:text-white'}`}>{t}</button>
                       ))}
                       <span className="text-gray-600">|</span>
                       <button className="text-xs text-gray-400 hover:text-white flex items-center"><span className="mr-1">Indicators</span></button>
                   </div>
               </div>
               <div className="flex items-center space-x-3">
                   <div className="flex flex-col items-end">
                       <span className={`text-sm font-sans tabular-nums font-bold ${currentPrice >= 0.03248 ? 'text-success' : 'text-danger'}`}>
                           {currentPrice.toFixed(5)} <span className="text-xs ml-1">{currentPrice >= 0.03248 ? '+0.65%' : '-0.21%'}</span>
                       </span>
                   </div>
                   <button className="text-gray-400 hover:text-white"><CameraIcon className="w-5 h-5" /></button>
               </div>
          </div>

          {/* Chart Canvas */}
          <div className="h-[350px] w-full bg-[#131722] relative">
              <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 10, right: 60, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} horizontal={true} />
                    <YAxis 
                      domain={[minPrice - padding, maxPrice + padding]} 
                      orientation="right" 
                      tick={{fontSize: 11, fill: '#0ECB81', fontFamily: 'Inter, sans-serif'}} 
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(val) => val.toFixed(5)}
                      width={60}
                    />
                    <XAxis dataKey="time" hide />
                    <Tooltip content={() => null} cursor={{stroke: '#ffffff', strokeDasharray: '3 3'}} />
                    <Bar
                      dataKey={(item: any) => [item.low, item.high]}
                      shape={(props: any) => <Candlestick {...props} open={props.payload.open} close={props.payload.close} high={props.payload.high} low={props.payload.low} />}
                      isAnimationActive={false}
                    />
                    {/* Mock MA Lines */}
                    <ReferenceLine stroke="#9333ea" strokeWidth={1} segment={[{x: 0, y: minPrice}, {x: 60, y: maxPrice}]} />
                  </BarChart>
              </ResponsiveContainer>
              
              {/* Floating Buy/Sell Buttons Overlay (Optional, but usually separate) */}
          </div>

          {/* Trading Controls Bar */}
          <div className="p-4 bg-darkblue2 border-t border-borderGray flex flex-col md:flex-row gap-4 items-center">
               <div className="flex border border-gray-600 rounded overflow-hidden">
                   <span className="bg-[#1E2329] text-gray-400 px-3 py-2 text-sm">IDR</span>
                   <input 
                      type="text" 
                      value="Stake Amount" 
                      disabled 
                      className="bg-transparent text-gray-500 px-3 py-2 text-sm w-32 outline-none" 
                   />
               </div>
               
               <div className="flex border border-gray-600 rounded overflow-hidden">
                   <div className="bg-[#1E2329] p-2"><ClockIcon className="w-5 h-5 text-gray-400"/></div>
                   <select className="bg-transparent text-white px-3 py-2 text-sm outline-none bg-darkblue2">
                       <option>1 Hour</option>
                   </select>
               </div>

               <div className="flex gap-2 w-full md:w-auto">
                   <button className="flex-1 md:flex-none bg-success hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded flex items-center justify-center">
                       <span className="bg-white text-success rounded-full w-4 h-4 flex items-center justify-center text-xs mr-2 font-bold">{'>'}</span>
                       Buy 100%
                   </button>
                   <button className="flex-1 md:flex-none bg-[#FFA07A] hover:bg-orange-400 text-white font-bold py-2 px-6 rounded flex items-center justify-center">
                       <span className="bg-white text-[#FFA07A] rounded-full w-4 h-4 flex items-center justify-center text-xs mr-2 font-bold">{'<'}</span>
                       Sell 100%
                   </button>
               </div>
          </div>
      </div>

      {/* 3. Stake Details Card */}
      <div className="bg-darkblue2 border border-borderGray rounded-lg p-0 mb-10">
          <div className="flex justify-between items-center p-4 border-b border-borderGray/50">
               <h3 className="text-xl text-gray-300">Stake <span className="text-gray-400">[6Z5YE5A359S8]</span></h3>
               <button className="bg-[#FFA07A] text-white text-xs px-2 py-1 rounded hover:bg-orange-500">Close</button>
          </div>
          
          <div className="p-6">
               <div className="text-center mb-6">
                   <p className="text-gray-500 text-sm font-bold mb-1">Time Remaining</p>
                   <p className="text-3xl sm:text-4xl font-sans tabular-nums font-bold text-danger tracking-wider">
                       {formatCountdown(countdown)}
                   </p>
               </div>

               <div className="space-y-0 divide-y divide-gray-800">
                   {/* Row 1: Stake Date */}
                   <div className="flex justify-between py-3 text-sm">
                       <span className="text-gray-400">Stake date :</span>
                       <span className="text-gray-300 font-sans tabular-nums">{formatDate(stakeDate)}</span>
                   </div>
                   
                   {/* Row 2: Market */}
                   <div className="flex justify-between py-3 text-sm">
                       <span className="text-gray-400">Market :</span>
                       <span className="text-gray-300 font-bold">ETH/BTC</span>
                   </div>

                   {/* Row 3: Amount */}
                   <div className="flex justify-between py-3 text-sm">
                       <span className="text-gray-400">Amount Stake :</span>
                       <span className="text-white font-sans tabular-nums font-bold">Rp {balance.toLocaleString('id-ID')}</span>
                   </div>

                   {/* Row 4: Type */}
                   <div className="flex justify-between py-3 text-sm items-center">
                       <span className="text-gray-400">Type :</span>
                       <span className="bg-success text-white text-[10px] font-bold px-2 py-1 rounded uppercase">Buy 1 Hour</span>
                   </div>

                   {/* Row 5: Date End */}
                   <div className="flex justify-between py-3 text-sm">
                       <span className="text-gray-400">Date End :</span>
                       <span className="text-gray-300 font-sans tabular-nums">{formatDate(endDate)}</span>
                   </div>

                   {/* Row 6: Rate Stake */}
                   <div className="flex justify-between py-3 text-sm">
                       <span className="text-gray-400">Rate Stake :</span>
                       <span className="text-gray-300 font-sans tabular-nums">0.06784600 BTC</span>
                   </div>
                   
                   {/* Row 7: Rate End */}
                   <div className="flex justify-between py-3 text-sm">
                       <span className="text-gray-400">Rate End :</span>
                       <span className="text-gray-500">---</span>
                   </div>

                   {/* Row 8: Status */}
                   <div className="flex justify-between py-3 text-sm items-center">
                       <span className="text-gray-400">Status :</span>
                       <span className="bg-warning text-white text-[10px] font-bold px-2 py-1 rounded flex items-center">
                           <span className="animate-spin h-3 w-3 mr-1 border-2 border-white border-t-transparent rounded-full"></span>
                           PENDING
                       </span>
                   </div>

                   {/* Row 9: Win/Lost */}
                   <div className="flex justify-between py-3 text-sm border-b-0">
                       <span className="text-gray-400">Win/Lost :</span>
                       <span className="text-gray-500">---</span>
                   </div>
               </div>
          </div>
      </div>

    </div>
  );
};

// Helper icon
const ClockIcon = ({className}:{className?:string}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

export default TradePage;