import React, { useState } from 'react';
import Header from '../dashboard/Header';
import Sidebar from '../dashboard/Sidebar';
import { InformationCircleIcon } from '@heroicons/react/24/outline';
import { useAuth } from '../../context/AuthContext';

interface DashboardLayoutProps {
  children?: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen bg-darkblue text-white font-sans">
      
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:ml-64 transition-all duration-300 ease-in-out">
        {/* Pass toggle function to Header because the hamburger button is now inside the Header for mobile */}
        <Header onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />
        
        {/* 
           Padding Top Calculation:
           Mobile: 
             - Logo Bar (~60px) 
             - Cyan Bar (64px) 
             - Ticker (40px)
             Total safe padding ~= 170px + extra spacing
           Desktop:
             - Blue Header (64px)
             - Ticker (40px)
             Total safe padding ~= 110px
        */}
        <main className="flex-1 p-4 pt-[180px] lg:pt-32">
          {/* Account Activation Alert */}
          {!user?.isVerified && (
            <div className="bg-danger/80 text-white p-4 rounded-lg shadow-lg mb-6 flex items-start">
              <InformationCircleIcon className="h-6 w-6 mr-3 flex-shrink-0" />
              <div>
                <h3 className="font-bold">Perhatian</h3>
                <p className="text-sm">
                  Soleh {user?.fullName}, silahkan lakukan pembayaran untuk mengaktifkan akun anda.
                </p>
              </div>
            </div>
          )}
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;