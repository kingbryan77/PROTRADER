import React from 'react';

interface AuthLayoutProps {
  children?: React.ReactNode;
}

const AuthLayout: React.FC<AuthLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden font-sans bg-gray-900">
      
      {/* Background Image (Static) */}
      <img
        src="https://images.unsplash.com/photo-1611974765270-ca1258634369?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" 
        alt="Trading Background"
        className="absolute top-0 left-0 w-full h-full object-cover z-0"
      />

      {/* Overlay to ensure text readability */}
      <div className="absolute inset-0 bg-black/60 z-0"></div>

      {/* Content Wrapper */}
      <div className="relative z-10 w-full flex flex-col items-center justify-center p-4">
        
        {/* Card Container - White Transparent (Glassmorphism) */}
        <div className="w-full max-w-md bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl p-8 sm:p-10 border border-white/10">
          {children}
        </div>

        {/* Footer Section */}
        <p className="mt-12 text-gray-400 text-xs drop-shadow-md">
          &copy; 2024 FOREXimf. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default AuthLayout;